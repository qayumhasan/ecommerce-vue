<?php
	sleep(3);
	echo json_encode(['status' => true]);