$(function () {

    $('#menu').metisMenu();

});
